You can create a horizontal rule by adding a line with three or more `*`, `-`, or `_` characters, optionally separated by spaces:

```markdown
***

---

___

* * * * * *
```