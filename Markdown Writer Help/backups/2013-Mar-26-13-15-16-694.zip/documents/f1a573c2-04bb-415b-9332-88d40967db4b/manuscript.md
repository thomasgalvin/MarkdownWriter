You can link to sections within a document using the header IDs (either automatically generated or specifically assigned):

```markdown
# Section One

Lorem ipsum dol amet sitor, consectetuer adipiscing elit. Donec dui. Integer 
tortor. Praesent adipiscing nibh sit amet lacus. 

Ut ut lorem et mi dignissim 
condimentum. Maecenas ac lectus quis pede dictum tempor. Proin convallis pede 
non lacus. Etiam nonummy arcu sit amet justo. 

Nulla et magna a justo mollis  venenatis. Donec eros. Praesent luctus urna sed 
mauris. Aliquam ultrices. Donec 
imperdiet, mi eu consequat sollicitudin.

# Section Two

Hey, remember what we were talking about in [Section One]?
```