This is kind of complicated, so you might want to check out the [Pandoc User's Guide](http://johnmacfarlane.net/pandoc/README.html#tables) for complete details.

Personally, I hate everything about markdown's table syntax (no matter which implementation you're talking about), and usually opt to include [inline html] instead, but your mileage may vary.