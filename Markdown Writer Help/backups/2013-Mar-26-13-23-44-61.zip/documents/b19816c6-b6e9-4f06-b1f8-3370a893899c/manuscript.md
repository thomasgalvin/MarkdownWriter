The `<` and `&` characters have special meaning in HTML, and you have to enter special codes to use them: `&lt;` and `&amp;`. Markdown generates this markdown for you.

You can escape any character (except in a code block) with a backslash. For example, the following would be in italics, not bold:

```markdown
*\*Hello, world!*\*
```