If an asterisk or underscore is surrounded by spaces, or is escaped, it will not trigger special formatting:

```markdown
This is * nothing particularly * important, and neither \*is this\*.
```