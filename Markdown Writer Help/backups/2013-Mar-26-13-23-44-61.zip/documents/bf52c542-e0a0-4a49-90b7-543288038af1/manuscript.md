You can make something superscript by surrounding it with carats (`^`):

```markdown
2^10 ^ is 1024;
```