Setext allows you to create a level-one header by underlining text with `=` signs:

```markdown
Document Title
==============
```

And level-two headers by underlining text with `-` signs:

```markdown
Chapter One
-----------
```

Headings can themselves contain markdown.