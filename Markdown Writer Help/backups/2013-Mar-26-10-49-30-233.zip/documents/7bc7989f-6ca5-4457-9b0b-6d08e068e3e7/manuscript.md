Markdown allows you to create preformatted (or code) blocks by indenting a paragraph by four spaces (or one tab):

```markdown
    for( int i = 0; i < 10; i++ )
    {
        System.out.println( i );
    }
```