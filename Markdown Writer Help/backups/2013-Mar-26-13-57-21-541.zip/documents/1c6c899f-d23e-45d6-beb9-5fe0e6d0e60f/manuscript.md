To use inline pre-formatting, surround text with one or more backticks (`` ` ``):

This is a snippet of code: `` for (int i = 0; i < 10; i++ ) ``