To emphasize part of a work, use asterisks:

```markdown
You emphasized the wrong syll*ab*le.
```