To use bold and italics together, use three asterisks (`***`) or underscores (`___`):

```markdown
This is ***very important***, and so is ___this___.
```