To *emphasize* text, surround it with a single asterisk (`*`) or underscore (`_`):

```markdown
This is *emphasized*, and so is _this_.
```