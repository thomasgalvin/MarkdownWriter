Pandoc allows LaTeX and ConTeXt to be added to documents, but it is ignored for most output formats.

