Or subscript by surrounding it with tildes (`~`):

```markdown
The formula for water is H~2~O
```