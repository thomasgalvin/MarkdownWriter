You can create traditional-looking hyperlinks by surrounding the link text is square brackets (`[` and `]`) and the including the link in parentheses (`(` and `)`) immediately after:

```markdown
This goes to [Google](http://www.google.com).
```

You can also add a tool-tip to hyperlinks:

```markdown
This goes to [Google](http://www.google.com "A search engine" ).
```