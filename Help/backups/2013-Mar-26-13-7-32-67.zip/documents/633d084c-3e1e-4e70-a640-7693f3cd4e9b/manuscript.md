Pandoc allows you to create definition lists. The *term* goes on the first line (and must fit on one line; it can't be wrapped). Each *definition* starts with a color (`:`) or tilde (`~`), followed by four spaces, followed by the definition.

Term 1
:    Definition one
:    Definition two
:    Definition three

     The second paragraph of definition three

     The third and final paragraph of definition three.
:    Definition four.