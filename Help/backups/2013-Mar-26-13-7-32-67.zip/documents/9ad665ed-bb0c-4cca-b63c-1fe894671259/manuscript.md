To **bold** text, surround it with two asterisks (`**`) or underscores (`__`);

```markdown
This is **bold**, and so is __this__.
```