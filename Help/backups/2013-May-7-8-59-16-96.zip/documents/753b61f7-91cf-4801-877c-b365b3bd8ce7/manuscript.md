The first kind of link you can create involves surrounding a well-formed URL with angle brackets (`<` and `>`):

```markdown
<http://www.google.com>
```

```markdown
<foo@bar.com>
```