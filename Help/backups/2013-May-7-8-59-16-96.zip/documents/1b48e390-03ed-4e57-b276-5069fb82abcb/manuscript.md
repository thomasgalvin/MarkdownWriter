Pandoc supports PHP Extra's pipe tables. The example from the [Pandoc User's Guide](http://johnmacfarlane.net/pandoc/README.html#pipe-tables):

| Right | Left | Default | Center |
|------:|:-----|---------|:------:|
|   12  |  12  |    12   |    12  |
|  123  |  123 |   123   |   123  |
|    1  |    1 |     1   |     1  |

  : Demonstration of simple table syntax.