You can also use internal links explicitly:

```markdown
Jump back to the [first section](#section-one)
```