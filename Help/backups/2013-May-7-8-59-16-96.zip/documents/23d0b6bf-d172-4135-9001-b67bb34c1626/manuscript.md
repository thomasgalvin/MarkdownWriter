You can add TeX Math to a document by surrounding it with two dollar signs (`$$`):

$$\forall x \in X, \quad \exists y \leq \epsilon$$