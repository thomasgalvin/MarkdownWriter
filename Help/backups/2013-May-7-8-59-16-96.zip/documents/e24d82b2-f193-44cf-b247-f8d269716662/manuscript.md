Pandoc also supports strikethrough, using two tildes (`~~`)

```markdown
Markdow Writer is available for ~~$99.99~~ free.
```